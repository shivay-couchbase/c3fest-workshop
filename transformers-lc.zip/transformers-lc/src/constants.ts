import {join} from "node:path";

export const DB_PATH = join(process.cwd(), 'database')
export const DOCS_PATH = join(process.cwd(), 'documents')